# NAPOpen LaTeX Template

LaTeX version of the NAPOpen MS Word manuscript template (North American Publication Corp., https://www.napopen.com).

## Files

| File | Purpose |
|---|---|
| `main.tex` | Sample manuscript. Start here and replace the text with your own. |
| `napopen.cls` | Document class: page layout, fonts, headings, captions, tables, header/footer, line numbers |
| `napopen.bbx` | Reference list style |
| `napopen.cbx` | In-text citation style: (Surname, Year) |
| `references.bib` | Sample references, one for each reference type |
| `napopen-logo.png` | NAPOpen logo shown in the page-1 header |
| `figures/` | Sample figures |

## Compiling

Use pdfLaTeX + Biber, which is the Overleaf default. Locally, run `latexmk -pdf main.tex`.

## Class options

```latex
\documentclass[submission]{napopen}  % default: line numbers + scope statement
\documentclass[final]{napopen}       % no line numbers, scope statement hidden
\documentclass[hyphenate]{napopen}   % allow hyphenation (the Word template has none)
```

## Commands

| Element | Command |
|---|---|
| Article type (page-1 header) | `\articletype{Article}` |
| Citation line and DOI | `\journalname{}` `\pubyear{}` `\pubvolume{}` `\pubpages{}` `\articledoi{}` |
| History dates | `\received{}` `\revised{}` `\accepted{}` `\published{}` |
| Authors | `\author{A. Author~\textsuperscript{1,\,*} and B. Author~\textsuperscript{2}}` |
| Affiliations | `\affil{1}{Department, Organization, City, State, Country}` |
| Corresponding author | `\correspondence{email}` and optional `\phone{}` |
| Keywords | `\keywords{keyword 1; keyword 2; keyword 3}` |
| Abstract | `\begin{abstract} ... \end{abstract}` after `\maketitle` |
| Scope statement | `\scopestatement{...}` (printed in submission mode only) |
| Figure and table references (bold) | `\figref{label}` → **Fig. 1**, `\tabref{label}` → **Table 1** |
| Table notes | `\begin{tablefooter} ... \end{tablefooter}` after the tabular |
| Unindented paragraph | `\noindentpar{text}` |
| Theorem-type environments | `theorem`, `proposition`, `lemma`, `corollary`, `definition` share one counter; `remark` and `example` are numbered separately; `\begin{proof}[Proof of Theorem 1]` |
| End matter | `\supplementary{}` `\dataavailability{}` `\authorcontributions{}` `\funding{}` `\acknowledgments{}` `\competinginterest{}`, or `\statement{Label}{text}` |
| Abbreviations | `\begin{abbreviations} NAP & North American Publication \\ \end{abbreviations}` |
| Appendices | `\appendix`, then `\section{}` → "Appendix A", `\subsection{}` → "Appendix A.1" |
| Citations | `\parencite{key}` → (Author, 2020); `\textcite{key}` → Author (2020) |
| Reference list | `\printbibliography[heading=napopen]` |

## Notes for authors

- Floats use `[!htbp]` by default; `[H]` (from the `float` package) fixes a figure or table in place.
- Write e-mail addresses and DOIs plainly (`\correspondence{first_last@uni.edu}`); underscores need no escaping.
- Don't load `authblk` (it clashes with `\affil`), and don't redefine `theorem`, `lemma`, `definition` etc., which the class already provides.
- Use `\parencite`/`\textcite`; avoid `\cite` inside section titles.

## Licence

Copyright (C) 2026 North American Publication Corp. The class and style files may be distributed and/or modified under the LaTeX Project Public License, version 1.3c or later (https://www.latex-project.org/lppl.txt). The NAPOpen logo is a trademark of North American Publication Corp. and is included for use with this template only.

## Font

The Word template is set in Palatino Linotype. That font is commercial and can't be distributed with a public template, so this class uses TeX Gyre Pagella through `newpxtext`/`newpxmath`. Pagella is a free version of the same Palatino design, and all point sizes are identical to the Word template.
