%% ===================================================================
%% napopen.cls -- LaTeX class for NAPOpen journal articles
%% North American Publication Corp. -- https://www.napopen.com
%%
%% Reproduces the NAPOpen MS Word template (nap-ms-word-template.docx).
%% All sizes, spacings and indents below are taken from the Word styles;
%% the Word style name is given next to each setting (NAP_x.x_...).
%%
%% Class options
%%   submission  (default) line numbers on, scope statement printed
%%   final       no line numbers, scope statement suppressed
%%   hyphenate   allow hyphenation (the Word template does not hyphenate)
%%
%% Compile with pdfLaTeX + Biber (Overleaf default).
%%
%% Copyright (C) 2026 North American Publication Corp.
%% This work may be distributed and/or modified under the conditions of
%% the LaTeX Project Public License, version 1.3c or later:
%% https://www.latex-project.org/lppl.txt
%% ===================================================================
\NeedsTeXFormat{LaTeX2e}
\ProvidesClass{napopen}[2026/10/22 v1.0 NAPOpen journal article class]

\newif\ifnap@final      \nap@finalfalse
\newif\ifnap@hyphenate  \nap@hyphenatefalse
\DeclareOption{submission}{\nap@finalfalse}
\DeclareOption{final}{\nap@finaltrue}
\DeclareOption{hyphenate}{\nap@hyphenatetrue}
\DeclareOption*{\PassOptionsToClass{\CurrentOption}{article}}
\ProcessOptions\relax

\LoadClass[10pt,a4paper]{article}

%% -------------------------------------------------------------------
%% Packages
%% -------------------------------------------------------------------
\RequirePackage[T1]{fontenc}
\RequirePackage{amsmath}
\RequirePackage{amsthm}           % must come before newpxmath
\RequirePackage{newpxtext}        % Palatino design (TeX Gyre Pagella)
\RequirePackage{newpxmath}        % matching Palatino maths
\RequirePackage[table]{xcolor}
\RequirePackage{graphicx}
\RequirePackage{array}
\RequirePackage{tabularx}
\RequirePackage{booktabs}
\RequirePackage{multirow}
\RequirePackage{float}            % allows [H] placement
\RequirePackage{etoolbox}
\RequirePackage{enumitem}
\RequirePackage[mathlines]{lineno}  % before caption
\RequirePackage{titlesec}
\RequirePackage{caption}
\RequirePackage{subcaption}
\RequirePackage{fancyhdr}
\RequirePackage{lastpage}
\RequirePackage{indentfirst}
\RequirePackage{csquotes}

%% -------------------------------------------------------------------
%% Page geometry (Word: A4; margins T 1411 / B 907 / L 1152 / R 720 tw)
%%
%% Nearly all body content in the Word template is indented 720 tw
%% (12.7 mm) from the left margin. Here the text column *is* that
%% indented column (left = 20.32 + 12.7 = 33.02 mm, width 164.18 mm);
%% the title block, abstract box and header/footer extend 12.7 mm
%% further left to the true margin.
%%
%% Top of text = where Word's running-header group ends
%% (12.7 mm header distance + header line + 4 pt line + rule + 24 pt).
%% -------------------------------------------------------------------
\RequirePackage[a4paper,
  left=33.02mm, right=12.7mm,
  top=26.9mm, bottom=16.4mm,
  headheight=20pt, headsep=8.47mm,
  footskip=14pt]{geometry}

\newlength\nap@outdent   \setlength\nap@outdent{12.7mm}    % 720 tw
\newlength\nap@fullwidth \setlength\nap@fullwidth{176.89mm}% 10028 tw
\newlength\nap@parindent \setlength\nap@parindent{21.6pt}  % 432 tw

%% -------------------------------------------------------------------
%% Colours (Word values)
%% -------------------------------------------------------------------
\definecolor{napbody}{HTML}{212529}   % NAP_4.x body, lists, tables
\definecolor{naptitle}{HTML}{333333}  % NAP_2.1_title
\definecolor{naplink}{HTML}{0000FF}   % Hyperlink character style

%% -------------------------------------------------------------------
%% Font sizes
%% Word "at least" line spacing -> fixed \baselineskip.
%% Word "single" lines use Palatino Linotype's natural line height
%% (about 1.32 x font size): 10 pt -> 13.2 pt, 8 pt -> 10.6 pt.
%% -------------------------------------------------------------------
\renewcommand\normalsize{%
  \@setfontsize\normalsize{10}{14}%       NAP_4.1.1_text: 10 pt, >= 14 pt
  \abovedisplayskip 6pt \abovedisplayshortskip 6pt
  \belowdisplayskip 6pt \belowdisplayshortskip 6pt
  \let\@listi\@listI}
\normalsize
\newcommand\nap@titlesize{\fontsize{18}{23.8}\selectfont}     % NAP_2.1
\newcommand\nap@authorsize{\fontsize{10}{13.2}\selectfont}    % NAP_2.2
\newcommand\nap@affilsize{\fontsize{8}{14}\selectfont}        % NAP_2.3
\newcommand\nap@historysize{\fontsize{7}{10.6}\selectfont}    % NAP_2.4
\newcommand\nap@hfsize{\fontsize{8}{10.6}\selectfont}         % NAP_1.4/1.5
\newcommand\nap@smallsize{\fontsize{9}{13}\selectfont}        % tables, end matter, refs
\newcommand\nap@captionsize{\fontsize{9}{14}\selectfont}      % captions
\newcommand\nap@notesize{\fontsize{7.5}{13}\selectfont}       % NAP_6.4_table_footer

%% -------------------------------------------------------------------
%% Paragraphs (NAP_4.1.1_text)
%% -------------------------------------------------------------------
\setlength\parindent{\nap@parindent}
\setlength\parskip{0pt}
\setlength\topskip{11pt}
\raggedbottom
\frenchspacing   % Word uses a single space after full stops
% Word widow/orphan control: never leave a single line of a paragraph
% at the top or bottom of a page
\clubpenalty=10000 \widowpenalty=10000 \displaywidowpenalty=10000
\ifnap@hyphenate\else
  % Word does not hyphenate this template; spaces stretch instead.
  % Lines may still break after an explicit hyphen, as in Word.
  \hyphenpenalty=10000
  \setlength\emergencystretch{3em}
\fi
\AtBeginDocument{\color{napbody}}

%% -------------------------------------------------------------------
%% Line numbers (Word: every line, continuous, Palatino 7.5 pt,
%% 0.25 in to the left of the true left margin)
%% -------------------------------------------------------------------
\renewcommand\linenumberfont{\normalfont\fontsize{7.5}{9}\selectfont\color{black}}
\setlength\linenumbersep{\dimexpr\nap@outdent+6.35mm\relax}
\ifnap@final\else
  \AtBeginDocument{\linenumbers}
\fi
\newcommand\nap@pauselinenumbers{\ifnap@final\else\nolinenumbers\fi}
\newcommand\nap@resumelinenumbers{\ifnap@final\else\linenumbers\fi}

%% -------------------------------------------------------------------
%% Article metadata
%% -------------------------------------------------------------------
\newcommand\nap@articletype{Type of the Paper}
\newcommand\nap@journal{Journal}
\newcommand\nap@pubyear{2026}
\newcommand\nap@volume{Vol}
\newcommand\nap@pages{pp}
\newcommand\nap@doi{10.19026/xxxxx}
\newcommand\nap@email{e-mail@email.com}
\let\nap@phone\@empty
\newcommand\nap@received{date}
\newcommand\nap@revised{date}
\newcommand\nap@accepted{date}
\newcommand\nap@published{date}
\let\nap@keywords\@empty
\newcommand\nap@affils{}

\newcommand\articletype[1]{\renewcommand\nap@articletype{#1}}
\newcommand\journalname[1]{\renewcommand\nap@journal{#1}}
\newcommand\pubyear[1]{\renewcommand\nap@pubyear{#1}}
\newcommand\pubvolume[1]{\renewcommand\nap@volume{#1}}
\newcommand\pubpages[1]{\renewcommand\nap@pages{#1}}
\newcommand\articledoi[1]{\edef\nap@doi{\detokenize{#1}}}
\newcommand\correspondence[1]{\edef\nap@email{\detokenize{#1}}}
\newcommand\phone[1]{\def\nap@phone{#1}}
\newcommand\received[1]{\renewcommand\nap@received{#1}}
\newcommand\revised[1]{\renewcommand\nap@revised{#1}}
\newcommand\accepted[1]{\renewcommand\nap@accepted{#1}}
\newcommand\published[1]{\renewcommand\nap@published{#1}}
\newcommand\keywords[1]{\def\nap@keywords{#1}}
%% \affil{<number>}{<affiliation text>}
\newcommand\affil[2]{\g@addto@macro\nap@affils{\nap@affilline{#1}{#2}}}
\newcommand\nap@affilline[2]{\par\textsuperscript{#1}\,#2}

%% "Journal 2026, Vol, pp" -- used in the page-1 footer and running head
\newcommand\nap@citeline{\nap@journal\ \textbf{\nap@pubyear}, \nap@volume, \nap@pages}

%% -------------------------------------------------------------------
%% Headers and footers
%% -------------------------------------------------------------------
\pagestyle{fancy}
\fancyhf{}
\fancyhfoffset[L]{\nap@outdent}
\renewcommand\headrulewidth{0pt}
\renewcommand\footrulewidth{0pt}

%% Pages 2+ (NAP_1.5_header_text + NAP_1.6_header_line):
%% 8 pt italic, right tab, 0.75 pt rule, 24 pt to the body.
\fancyhead[L]{\raisebox{-1.67mm}[0pt][0pt]{\parbox[b]{\headwidth}{%
    \color{black}\nap@hfsize\itshape
    \nap@citeline\hfill\thepage\ of \pageref*{LastPage}\par
    \kern 5pt\hrule height 0.75pt}}}

%% Page 1 (NAP_1.3_footer_line + NAP_1.4_footer_text):
%% 0.5 pt rule, 4 pt line, 8 pt italic citation line and DOI.
\fancypagestyle{napfirst}{%
  \fancyhf{}%
  \fancyfoot[L]{\raisebox{\dimexpr14pt-2.85mm\relax}[0pt][0pt]{\parbox[b]{\headwidth}{\color{black}\nap@hfsize\itshape
      \hrule height 0.5pt\kern 1.41mm
      \hbox to \hsize{\vrule height 2.9mm width 0pt
        \nap@citeline\hfill\nap@doilink}}}}}

\newcommand\nap@doilink{\ifdefined\href
  \href{https://doi.org/\nap@doi}{\nolinkurl{https://doi.org/\nap@doi}}%
  \else https://doi.org/\nap@doi\fi}

%% -------------------------------------------------------------------
%% Title block (\maketitle)
%% -------------------------------------------------------------------
\renewcommand\maketitle{%
  \thispagestyle{napfirst}%
  % Page 1 footer is taller than the bottom margin; Word pushes the
  % body up to 26.3 mm from the bottom on this page only.
  \enlargethispage{-9.9mm}%
  % --- Page-1 header row (NAP_1.1_header; 5040 + 5040 tw table) -----
  % Placed 22.86 mm from the page top (Word header distance 1296 tw).
  \vspace*{-\dimexpr\topskip+4.04mm\relax}%
  \nointerlineskip
  \moveleft\nap@outdent\vbox to 6.83mm{\hsize\nap@fullwidth
    \vss
    \hbox to\hsize{\hskip 5.4pt\color{black}%
      \fontsize{10}{13.2}\selectfont\bfseries\itshape\nap@articletype
      \hfil\raisebox{-0.35\height}{\includegraphics[width=29.72mm]{napopen-logo}}}%
    \vss}%
  \nointerlineskip
  \moveleft\nap@outdent\vbox{\hrule width\nap@fullwidth height 0.5pt}%
  % empty NAP_1.2_header paragraph (8 pt)
  \vskip 1.83mm
  \begingroup
    % centred across the full text width (true margins)
    \parindent\z@ \parfillskip\z@
    \leftskip=\dimexpr-\nap@outdent\relax plus 1fil \rightskip=\z@ plus 1fil
    \color{black}%
    % NAP_2.1_title: 18 pt bold, #333333, after 12 pt
    {\nap@titlesize\bfseries\color{naptitle}\@title\par}%
    \vskip 14.4pt
    % NAP_2.2_authorname: 10 pt bold, after 6 pt
    {\nap@authorsize\bfseries\@author\par}%
    \vskip 6pt
    % NAP_2.3_affiliation: 8 pt, >= 14 pt, after last 24 pt
    {\nap@affilsize\nap@affils\par}%
  \endgroup
  \vskip 24pt
  \setcounter{footnote}{0}%
}

%% -------------------------------------------------------------------
%% Abstract box: history column | abstract + keywords
%% (front-matter table: 2448 + 7632 tw, 0.75 pt rule between columns)
%% -------------------------------------------------------------------
\newlength\nap@histwidth \setlength\nap@histwidth{\dimexpr43.18mm-10.8pt\relax}
\newlength\nap@abswidth  \setlength\nap@abswidth{\dimexpr133.71mm-10.8pt-0.75pt\relax}

\newcommand\nap@historycolumn{%
  \nap@historysize\raggedright
  \textbf{* Correspondence}\par
  \nap@email\par
  \ifx\nap@phone\@empty\else Tel: \nap@phone\par\fi
  \vspace{6pt}%
  \textbf{Received:} \nap@received\par
  \textbf{Revised:} \nap@revised\par
  \textbf{Accepted:} \nap@accepted\par
  \textbf{Published:} \nap@published\par
  \vspace{6pt}%
  \textbf{Copyright:} \textcopyright\ The Author(s) \nap@pubyear.
  Submitted with the intention of open access publication in
  accordance with the Creative Commons Attribution (CC BY) license
  terms (\nap@cclink).\par}
\newcommand\nap@cclink{\ifdefined\href
  \href{https://creativecommons.org/licenses/by/4.0/}%
       {\nolinkurl{https://creativecommons.org/licenses/by/4.0/}}%
  \else https://creativecommons.org/licenses/by/4.0/\fi}

\renewenvironment{abstract}{%
  \par\nap@pauselinenumbers
  \nointerlineskip
  % Table top 24 pt below the affiliations; "Abstract" baseline 3 pt +
  % one 10 pt line below the table top.
  \setlength\extrarowheight{3.4pt}%
  \noindent\hspace*{-\nap@outdent}\color{black}%
  \begin{tabular}[t]{@{\hspace{5.4pt}}p{\nap@histwidth}@{\hspace{5.4pt}}%
                  !{\vrule width 0.75pt}%
                  @{\hspace{5.4pt}}p{\nap@abswidth}@{\hspace{5.4pt}}}
  \nap@historycolumn &
  \normalsize\parindent\z@
  % NAP_2.5_abstract_heading: 10 pt bold, before 3, after 6
  {\fontsize{10}{13.2}\selectfont\bfseries Abstract\par}%
  \vspace{6pt}%
  % NAP_2.6_abstract_text: 10 pt, >= 14 pt, justified
}{%
  \unskip
  \ifx\nap@keywords\@empty\else
    % NAP_2.7_keywords: before 18, after 6
    \par\vspace{18pt}\noindent\textbf{Keywords:} \nap@keywords
  \fi
  % 6 pt after the last line (cell must not end with \par)
  \rule[-8.4pt]{0pt}{8.4pt}%
  \end{tabular}\par
  % NAP_2.8_line: 24 pt, then 0.75 pt rule from the content indent
  \vskip 24pt
  \hrule height 0.75pt
  \kern 6.6pt\prevdepth\z@
  \nap@resumelinenumbers
}

%% Scope statement (internal; printed in submission mode only)
\newcommand\scopestatement[1]{%
  \ifnap@final\else
    \section*{Scope statement:}#1\par
  \fi}

%% -------------------------------------------------------------------
%% Section headings
%% NAP_3.1_headings_1  12 pt bold, UPPERCASE, before 12, after 3
%% NAP_3.2_heading_2   10 pt bold, before 12, after 3
%% NAP_3.3_heading_3   10 pt regular, before 3, after 3
%% Level-1 number set in a 6.35 mm box (Word auto-numbering tab).
%% -------------------------------------------------------------------
\setcounter{secnumdepth}{3}
% A heading directly after another heading keeps its own space-before
% (Word adds space-after + space-before; titlesec would drop it).
\def\ttl@titlespace#1{\vskip#1\relax}
\titleformat{\section}
  {\normalfont\fontsize{12}{14}\selectfont\bfseries\color{black}}
  {\makebox[6.35mm][l]{\thesection.}}{0pt}{\MakeUppercase}
\titleformat{name=\section,numberless}
  {\normalfont\fontsize{12}{14}\selectfont\bfseries\color{black}}
  {}{0pt}{}
\titleformat{\subsection}
  {\normalfont\fontsize{10}{14}\selectfont\bfseries\color{black}}
  {\thesubsection.}{0.3em}{}
\titleformat{\subsubsection}
  {\normalfont\fontsize{10}{14}\selectfont\color{black}}
  {\thesubsubsection.}{0.3em}{}
\titlespacing*{\section}{0pt}{12pt}{3pt}
\titlespacing*{\subsection}{0pt}{12pt}{3pt}
\titlespacing*{\subsubsection}{0pt}{3pt}{3pt}

%% Appendix: "Appendix A", "Appendix A.1"; floats/equations A1, A2 ...
\newcommand\nap@apptitle[1]{\if\relax\detokenize{#1}\relax\else: #1\fi}
\renewcommand\appendix{\par
  \setcounter{section}{0}\setcounter{subsection}{0}%
  \renewcommand\thesection{\Alph{section}}%
  \titleformat{\section}
    {\normalfont\fontsize{12}{14}\selectfont\bfseries\color{black}}
    {Appendix \thesection}{0pt}{\nap@apptitle}%
  \titleformat{\subsection}
    {\normalfont\fontsize{10}{14}\selectfont\bfseries\color{black}}
    {Appendix \thesubsection}{0pt}{\nap@apptitle}%
  \counterwithin{figure}{section}\renewcommand\thefigure{\thesection\arabic{figure}}%
  \counterwithin{table}{section}\renewcommand\thetable{\thesection\arabic{table}}%
  \counterwithin{equation}{section}\renewcommand\theequation{\thesection\arabic{equation}}%
}

%% -------------------------------------------------------------------
%% Lists
%% NAP_4.2_bullets: bullet at the content indent, text +7.62 mm
%% NAP_4.3_itemize: number at +11.11 mm, text at +18.73 mm
%% -------------------------------------------------------------------
\setlist{topsep=0pt, partopsep=0pt, itemsep=0pt, parsep=0pt}
\setlist[itemize,1]{label=\textbullet, labelindent=0pt, labelwidth=7.62mm,
  labelsep=0pt, leftmargin=7.62mm, align=left}
\setlist[enumerate,1]{label=\arabic*., labelindent=11.11mm, labelwidth=7.62mm,
  labelsep=0pt, leftmargin=18.73mm, align=left}
%% Second level (not used in the Word sample): same 7.62 mm step
\setlist[itemize,2]{label=\textopenbullet, labelindent=0pt, labelwidth=7.62mm,
  labelsep=0pt, leftmargin=7.62mm, align=left}
\setlist[enumerate,2]{label=\alph*), labelindent=0pt, labelwidth=7.62mm,
  labelsep=0pt, leftmargin=7.62mm, align=left}

%% -------------------------------------------------------------------
%% Figures and tables
%% NAP_5.2_figure_caption / NAP_6.1_table_caption: 9 pt, >= 14 pt,
%% "Figure 1:" bold, justified, black. Figure caption below (12 pt),
%% table caption above (6 pt). 12 pt above and below each float.
%% -------------------------------------------------------------------
\DeclareCaptionFont{napcaption}{\nap@captionsize\color{black}}
\captionsetup{font=napcaption, labelfont=bf, labelsep=colon,
  justification=justified, singlelinecheck=false, margin=0pt}
\captionsetup[figure]{position=bottom, skip=12pt}
\captionsetup[table]{position=top, skip=6pt}
%% NAP_5.5_figure_panel_a: "(a)" 9 pt bold, centred under each panel
\DeclareCaptionFont{nappanel}{\fontsize{9}{13}\selectfont\bfseries\color{napbody}}
\captionsetup[sub]{font=nappanel, labelformat=parens, labelsep=space,
  justification=centering, skip=2pt}

\setlength\intextsep{12pt}
\setlength\textfloatsep{12pt plus 2pt}
\setlength\floatsep{12pt plus 2pt}
\def\fps@figure{!htbp}
\def\fps@table{!htbp}
%% Inside every float box: centred; tables also get the 9 pt table font
%% and body colour (set inside the box so nothing leaks into the page)
\def\nap@tabletype{table}
\g@addto@macro\@floatboxreset{\centering
  \ifx\@captype\nap@tabletype\nap@smallsize\color{napbody}\fi}

%% NAP_6.2/6.3_table_header/body: 9 pt, >= 13 pt; cell padding 5.4 pt;
%% horizontal rules 0.75 pt, no vertical rules.
\setlength\tabcolsep{5.4pt}
\setlength\heavyrulewidth{0.75pt}
\setlength\lightrulewidth{0.75pt}
\setlength\cmidrulewidth{0.75pt}
\setlength\aboverulesep{0pt}
\setlength\belowrulesep{0pt}
\setlength\cmidrulekern{0pt}

%% NAP_6.4_table_footer: 7.5 pt notes directly below the table
\newenvironment{tablefooter}
  {\par\nap@notesize\color{napbody}\raggedright\noindent\ignorespaces}
  {\par}

%% Bold cross-references, as in the Word template: Fig. 1, Table 1
\newcommand\figref[1]{\textbf{Fig.~\ref{#1}}}
\newcommand\tabref[1]{\textbf{Table~\ref{#1}}}

%% -------------------------------------------------------------------
%% Theorems (NAP_4.8_theorem): 12 pt above/below, head indented like
%% body text, "Theorem 1:" bold, statement italic.
%% Theorem, proposition, lemma, corollary share one counter;
%% remark and example are numbered separately.
%% -------------------------------------------------------------------
\newtheoremstyle{napthm}{12pt}{12pt}{\itshape}{\nap@parindent}{\bfseries}{:}{ }{}
\newtheoremstyle{napplain}{12pt}{12pt}{\normalfont}{\nap@parindent}{\bfseries}{:}{ }{}
\theoremstyle{napthm}
\newtheorem{theorem}{Theorem}
\newtheorem{proposition}[theorem]{Proposition}
\newtheorem{lemma}[theorem]{Lemma}
\newtheorem{corollary}[theorem]{Corollary}
\newtheorem{definition}[theorem]{Definition}
\theoremstyle{napplain}
\newtheorem{remark}{Remark}
\newtheorem{example}{Example}

%% "Proof of Theorem 1:" bold, upright text, ends with the QED mark
\renewenvironment{proof}[1][\proofname]{\par
  \pushQED{\qed}\normalfont\topsep 12pt\relax
  \trivlist\item[\hskip\labelsep\hskip\nap@parindent\bfseries #1:]\ignorespaces
}{\popQED\endtrivlist\@endpefalse}

%% -------------------------------------------------------------------
%% End matter (NAP_4.9.1 / 4.9.2): 9 pt, >= 13 pt, bold run-in label,
%% 6 pt after each item, 12 pt before the first.
%% -------------------------------------------------------------------
\newif\ifnap@emfirst \nap@emfirsttrue
\newcommand\statement[2]{%
  \par
  \ifnap@emfirst\vskip 12pt\global\nap@emfirstfalse\fi
  {\nap@smallsize\color{black}\noindent\textbf{#1:} #2\par}%
  \kern 6pt}
\newcommand\supplementary[1]{\statement{Supplementary Materials}{#1}}
\newcommand\dataavailability[1]{\statement{Data Availability Statement}{#1}}
\newcommand\authorcontributions[1]{\statement{Author Contributions}{#1}}
\newcommand\funding[1]{\statement{Funding}{#1}}
\newcommand\acknowledgments[1]{\statement{Acknowledgments}{#1}}
\newcommand\competinginterest[1]{\statement{Competing Interest}{#1}}

%% Abbreviations list (borderless 2-column table, 1008 + 8352 tw, 9 pt)
\newenvironment{abbreviations}{%
  \par\vskip 12pt
  \nap@pauselinenumbers
  \noindent\nap@smallsize\color{napbody}%
  \begin{tabular}{@{\hspace{5.4pt}}p{\dimexpr17.78mm-10.8pt\relax}@{\hspace{10.8pt}}%
                  p{\dimexpr\linewidth-17.78mm-5.4pt\relax}@{}}%
}{\end{tabular}\par\nap@resumelinenumbers}

%% NAP_4.1.2_text_no_indent: no first-line indent, black
\newcommand\noindentpar[1]{\par{\noindent\color{black}#1\par}}

%% -------------------------------------------------------------------
%% References (biblatex; style defined in napopen.bbx / napopen.cbx)
%% NAP_7.1_reference: 9 pt, >= 13 pt, hanging indent 6.35 mm
%% -------------------------------------------------------------------
\RequirePackage[backend=biber, bibstyle=napopen, citestyle=napopen,
  sorting=nyt, maxcitenames=2, mincitenames=1,
  maxbibnames=999, minbibnames=999, giveninits=true,
  uniquename=false, uniquelist=false, date=year, urldate=long]{biblatex}
\renewcommand*\bibfont{\nap@smallsize\color{black}}
\setlength\bibhang{6.35mm}
\setlength\bibitemsep{0pt}
\defbibheading{napopen}[REFERENCES]{\section*{#1}}

%% -------------------------------------------------------------------
%% Hyperlinks: URLs blue (Word Hyperlink style); other links uncoloured
%% -------------------------------------------------------------------
\RequirePackage{hyperref}
\hypersetup{colorlinks=true, linkcolor=., citecolor=., filecolor=.,
  urlcolor=naplink, pdfborder={0 0 0}}
\urlstyle{same}
\def\UrlBigBreaks{}
\Urlmuskip=0mu plus 1mu
\pdfstringdefDisableCommands{\def\\{ }\def\textsuperscript#1{}}
\AtBeginDocument{\hypersetup{pdftitle={\@title}}}

\endinput